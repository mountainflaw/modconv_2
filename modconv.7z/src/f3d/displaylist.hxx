#pragma once
#include "vertex.hxx"
void build_displaylist(const std::string fileOut, Vertex *vtx, Material *mats, s32 verts, s8 f3d);
